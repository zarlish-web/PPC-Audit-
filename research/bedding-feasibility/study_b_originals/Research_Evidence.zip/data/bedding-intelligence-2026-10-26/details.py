import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
B=Path(__file__).parent
async def main():
 async with async_playwright() as p:
  b=await p.chromium.connect_over_cdp('http://127.0.0.1:18801');ctx=await b.new_context(locale='en-US');sem=asyncio.Semaphore(3)
  jobs=[]
  for country in ['US','CA','UK']:
   for seg in ['sheets','duvet','protector','bamboo','topper']:
    f=B/f'LIVE_{country}_{seg}.json'
    if not f.exists():continue
    d=json.loads(f.read_text());cards=d['cards']
    if cards:jobs.append((country,seg,cards[0]['asin']))
  async def one(country,seg,asin):
   async with sem:
    pg=await ctx.new_page();url='https://www.amazon.'+{'US':'com','CA':'ca','UK':'co.uk'}[country]+'/dp/'+asin
    try:
     await pg.goto(url,wait_until='domcontentloaded',timeout=40000);await pg.wait_for_timeout(1200)
     txt=await pg.locator('body').inner_text()
     reviews=await pg.locator('[data-hook="review"]').evaluate_all('(es)=>es.map(e=>({id:e.id,text:e.innerText}))')
     d={'country':country,'segment':seg,'asin':asin,'url':url,'date':'2026-10-26','text':txt,'reviews':reviews,'aplus_elements':await pg.locator('#aplus, #aplus_feature_div').count(),'image_thumbnails':await pg.locator('#altImages img').count(),'byline':await pg.locator('#bylineInfo').all_inner_texts()}
     (B/f'PDP_{country}_{seg}.json').write_text(json.dumps(d,indent=2));print(country,seg,asin,'reviews',len(reviews),'byline',d['byline'],flush=True)
    except Exception as e:print(country,seg,str(e)[:100],flush=True)
    finally:await pg.close()
  await asyncio.gather(*[one(*j) for j in jobs]);await ctx.close()
asyncio.run(main())
