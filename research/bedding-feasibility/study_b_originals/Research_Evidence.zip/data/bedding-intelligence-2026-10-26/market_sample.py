import asyncio,json,sys
from pathlib import Path
from urllib.parse import quote
from playwright.async_api import async_playwright
B=Path(__file__).parent
QUERIES={'sheets':'cotton sheet set','duvet':'cotton duvet cover set','protector':'waterproof mattress protector','fitted':'deep pocket fitted sheet','pillowcase':'cotton pillowcases','comforter':'comforter set','quilt':'cotton quilt','topper':'mattress topper','linen':'linen sheet set','bamboo':'bamboo viscose sheet set','lyocell':'lyocell sheet set'}
async def main():
 country=sys.argv[1];dom={'US':'com','CA':'ca','UK':'co.uk'}[country]
 async with async_playwright() as p:
  b=await p.chromium.connect_over_cdp('http://127.0.0.1:18801');ctx=await b.new_context(locale='en-US');page=await ctx.new_page()
  if country=='US':
   await page.goto('https://www.amazon.com/customer-preferences/edit?ref_=footer_cop',wait_until='domcontentloaded')
   await page.locator('input[name="cop"][value="USD"]').check(force=True)
   await page.locator('input[type="submit"]').last.click();await page.wait_for_timeout(1200)
   await page.locator('#nav-global-location-popover-link').click();await page.locator('#GLUXZipUpdateInput').fill('10001');await page.locator('#GLUXZipUpdate').click();await page.wait_for_timeout(1800)
   print('LOCATION DIALOG', (await page.locator('body').inner_text())[-1600:],flush=True)
   for label in ['Continue','Done']:
    loc=page.get_by_role('button',name=label,exact=True)
    if await loc.count():
     try: await loc.last.click(timeout=2500)
     except:pass
   await page.wait_for_timeout(1000)
  if country=='UK':
   await page.goto('https://www.amazon.co.uk/',wait_until='domcontentloaded');await page.wait_for_timeout(1000)
   if await page.get_by_role('button',name='Continue shopping').count():
    try:await page.get_by_role('button',name='Continue shopping').click(timeout=3000)
    except:pass
   await page.goto('https://www.amazon.co.uk/customer-preferences/edit?ref_=footer_cop',wait_until='domcontentloaded')
   if await page.locator('input[name="cop"][value="GBP"]').count():
    await page.locator('input[name="cop"][value="GBP"]').check(force=True)
    await page.locator('input[type="submit"]').last.click();await page.wait_for_timeout(1200)
  sem=asyncio.Semaphore(2)
  async def one(seg,q):
   async with sem:
    pg=await ctx.new_page();url=f'https://www.amazon.{dom}/s?k='+quote(q)
    try:
     await pg.goto(url,wait_until='domcontentloaded',timeout=45000);await pg.wait_for_timeout(1100)
     txt=await pg.locator('body').inner_text();cards=await pg.locator('[data-component-type="s-search-result"]').evaluate_all('''(es)=>es.map(e=>({asin:e.getAttribute('data-asin'),text:e.innerText,title:e.querySelector('h2')?.innerText,price:e.querySelector('.a-price .a-offscreen')?.innerText,sponsored:/Sponsored/i.test(e.innerText),link:e.querySelector('h2 a')?.href}))''')
     d={'id':f'LIVE_{country}_{seg}','country':country,'segment':seg,'query':q,'url':url,'research_date':'2026-10-26','location_header':txt[:950],'text':txt,'cards':cards}
     (B/(d['id']+'.json')).write_text(json.dumps(d,indent=2));print(d['id'],len(cards),cards[:1],flush=True)
    except Exception as e:print(seg,str(e)[:120],flush=True)
    finally:await pg.close()
  await asyncio.gather(*[one(s,q) for s,q in QUERIES.items()]);await ctx.close()
asyncio.run(main())
