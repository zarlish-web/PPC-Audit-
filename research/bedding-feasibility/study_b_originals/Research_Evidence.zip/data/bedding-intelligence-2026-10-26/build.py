import json,re,math,statistics,collections,os
from pathlib import Path
import xlsxwriter
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
B=Path(__file__).parent;O=Path('reports/bedding-intelligence-2026-10-26');O.mkdir(parents=True,exist_ok=True)
load=lambda f:json.loads((B/f).read_text())
products=load('products.json');stats=load('sample_stats.json');reviews=load('reviews_coded.json');rs=load('review_stats.json');content=load('content.json');models=load('models.json');sources=load('final_sources.json')
navy='#1B365D';blue='#4472C4';plt.rcParams.update({'font.family':'Arial','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold','axes.labelcolor':navy,'text.color':navy})
market=[['US',32748.9,8.8,75.19,26480,42.15,27500,3.86,'M01; M07'],['CA',6061.7,10.9,78.07,3120,43.77,3290,4.58,'M02; M09'],['UK',8016.7,7.2,67.46,7620,45.92,7750,1.76,'M03; M08']]
charts=[]
def save(fig,name):
 fig.savefig(O/(name+'.png'),dpi=180,bbox_inches='tight');fig.savefig(O/(name+'.pdf'),bbox_inches='tight');plt.close(fig);charts.append(name)
fig,axs=plt.subplots(1,2,figsize=(11,4.5))
for ax,col,title in [(axs[0],1,'Broad home bedding, 2024'),(axs[1],None,'Derived bed linen, 2025')]:
 vals=[r[col]/1000 if col else r[4]*r[5]/100/1000 for r in market];ax.bar([r[0] for r in market],vals,color=[navy,blue,'#78A7C4']);ax.set_ylabel('USD billion');ax.set_title(title)
 for i,v in enumerate(vals):ax.text(i,v+.1,f'{v:.2f}',ha='center')
fig.suptitle('Market scope changes the addressable opportunity');fig.text(.02,-.02,'Left: GVR estimates include mattresses. Right: Mordor home-textile revenue x bed-linen share. Different scopes/years; neither is Amazon TAM. Sources M01-M03/M07-M09.',fontsize=8);fig.tight_layout();save(fig,'01_market_scope')
fig,axs=plt.subplots(1,3,figsize=(12,4.5))
for ax,c in zip(axs,['US','CA','UK']):
 data=[];labels=[]
 for seg in ['sheets','duvet','protector']:
  a=[r['display_price'] for r in products if r['country']==c and r['segment']==seg and r['query_match_screen'] and r['display_price'] is not None]
  data.append(a);labels.append(seg+'\nn='+str(len(a)))
 ax.boxplot(data,tick_labels=labels,showfliers=True,patch_artist=True,boxprops={'facecolor':'#D5E8F0'});ax.set_title(c+' '+{'US':'USD','CA':'CAD','UK':'GBP'}[c]);ax.set_ylabel('Displayed price, before conditional coupons')
fig.suptitle('Discovery-sample price distributions, not normalized market prices');fig.text(.02,-.02,'33 anonymous query snapshots, 26 Oct 2026. Mixed sizes/sets; title-screened materials. US/UK overseas destination retained; UK tax treatment at checkout unverified.',fontsize=8);fig.tight_layout();save(fig,'02_price_distributions')
fig,axs=plt.subplots(1,2,figsize=(11,4.5))
for c,color in zip(['US','CA','UK'],[navy,blue,'#78A7C4']):
 vals=[next(s['median_ratings'] for s in stats if s['country']==c and s['segment']==g) for g in ['sheets','duvet','protector']];axs[0].plot(['Sheets','Duvet covers','Protectors'],vals,marker='o',label=c,color=color)
axs[0].set_yscale('log');axs[0].set_ylabel('Median displayed ratings count (log scale)');axs[0].legend();axs[0].set_title('Visible trust barriers')
sel=[s for s in stats if s['segment']=='duvet'];vals=[s['top3_known_card_share']*100 for s in sel];axs[1].bar([s['country'] for s in sel],vals,color=blue);axs[1].set_ylim(0,100);axs[1].set_ylabel('% of brand-resolved duvet cards');axs[1].set_title('Top-three observed-brand concentration')
for i,s in enumerate(sel):axs[1].text(i,vals[i]+2,f"{s['brand_resolved']}/{s['cards']} resolved",ha='center',fontsize=8)
fig.text(.02,-.03,'Discovery only. Ratings may pool countries/variants, are rounded, and are not text-review counts. Right: card visibility among resolved brands, NOT sales share/HHI.',fontsize=8);fig.tight_layout();save(fig,'03_barriers_concentration')
fig,ax=plt.subplots(figsize=(8,4.5));base=next(m for m in models if m['id']=='US-Medium');cpcs=[.5,.75,1,1.25,1.5,2];cvrs=[.03,.05,.08,.10,.15];grid=np.array([[base['pre_ad']-c/v for c in cpcs] for v in cvrs]);im=ax.imshow(grid,cmap='RdYlGn',aspect='auto',vmin=-35,vmax=20)
ax.set_xticks(range(len(cpcs)),[f'${x:.2f}' for x in cpcs]);ax.set_yticks(range(len(cvrs)),[f'{x:.0%}' for x in cvrs]);ax.set_xlabel('Assumed CPC');ax.set_ylabel('Assumed click-to-order CVR');ax.set_title('US medium case: contribution per ad-acquired order (USD)')
for y in range(len(cvrs)):
 for x in range(len(cpcs)):ax.text(x,y,f'{grid[y,x]:.1f}',ha='center',va='center',color='black')
fig.colorbar(im,ax=ax);fig.text(.02,-.02,'SCENARIO, not observed ad performance. Pre-ad contribution fixed at USD '+f"{base['pre_ad']:.2f}"+'. CPA=CPC/CVR. Returns and discount included in base case.',fontsize=8);fig.tight_layout();save(fig,'04_ad_economics')
fig,axs=plt.subplots(1,3,figsize=(12,4.5))
for ax,c in zip(axs,['US','CA','UK']):
 subset=[m for m in models if m['country']==c];bottom=np.zeros(3)
 for k,label,col in [('inventory_cash','Inventory','#1B365D'),('reorder_cash','Reorder deposit','#4472C4'),('launch_setup','Setup','#78A7C4'),('launch_media','Ads','#A7C6DA'),('operating_runway','3mo overhead','#79937A'),('tax_float','Tax float','#BCB09F'),('reserve','Reserve','#D5E8F0')]:
  vals=np.array([m[k]/1000 for m in subset]);ax.bar([m['tier'] for m in subset],vals,bottom=bottom,label=label,color=col);bottom+=vals
 ax.set_title(c+' '+subset[0]['currency']);ax.set_ylabel('Local currency thousands')
axs[2].legend(fontsize=7,loc='upper left',bbox_to_anchor=(1,1));fig.suptitle('Illustrative launch cash, not supplier quotations');fig.text(.02,-.02,'Separate currency panels; no FX comparison. Inventory/deposits/tax float are working capital, not all immediate expenses. Larger cases can lose money.',fontsize=8);fig.tight_layout();save(fig,'05_launch_capital')
fig,ax=plt.subplots(figsize=(10,5));opps=sorted(content['opportunities'],key=lambda o:o[-1]);labels=[o[0]+' '+o[1]+' '+o[2] for o in opps];ax.barh(labels,[o[-1] for o in opps],color=[blue if o[0] in ['O1','O2','O3','O4','O5'] else '#B7C4CE' for o in opps]);ax.set_xlim(0,100);ax.set_xlabel('Weighted analyst screen, not probability or forecast');ax.set_title('Feasibility priority: close scores are not decision-grade rankings');fig.text(.02,-.02,'Evidence-informed 1-5 judgements; 9 dimensions. Top five within 5 points; most confidence low to medium-low. CAC and supplier economics remain unverified.',fontsize=8);fig.tight_layout();save(fig,'06_opportunity_scorecard')
# Workbook
w=xlsxwriter.Workbook(O/'Bedding_Market_Intelligence.xlsx');w.set_properties({'title':'Independent Bedding Market Intelligence','comments':'Research 2026-10-26; evidence-limited feasibility screen, not investment approval.'})
hdr=w.add_format({'bold':True,'font_name':'Arial','font_size':11,'font_color':'white','bg_color':navy,'text_wrap':True,'valign':'top'})
body=w.add_format({'font_name':'Arial','font_size':10,'text_wrap':True,'valign':'top'});inp=w.add_format({'font_name':'Arial','font_size':10,'font_color':'#0000FF','num_format':'0.00'});formula=w.add_format({'font_name':'Arial','font_size':10,'num_format':'0.00'});pct=w.add_format({'font_name':'Arial','font_size':10,'num_format':'0.0%'});title=w.add_format({'font_name':'Arial','font_size':18,'bold':True,'font_color':navy})
def sheet(name,headers,rows):
 s=w.add_worksheet(name);s.freeze_panes(1,0);s.set_default_row(48);s.set_row(0,36);s.write_row(0,0,headers,hdr)
 for i,row in enumerate(rows,1):
  for j,v in enumerate(row):s.write(i,j,'' if v is None else v,body)
 s.autofilter(0,0,len(rows),len(headers)-1);s.set_column(0,len(headers)-1,24,body);s.set_landscape();s.fit_to_pages(1,0);s.repeat_rows(0);return s
readme=[['Status','Evidence-limited research package. Public evidence collected; domestic rank panels, measured keyword demand/CPC/CVR, competitor sales, quotes and review histories are NOT verified.'],['Date','26 October 2026; geography split US/CA/UK. Monetary currency explicit in every financial table.'],['Legend','FACT=observed official/page evidence; CLAIM=seller assertion; ESTIMATE=publisher model; CALC=derived; ASSUMPTION=analyst scenario; GAP=unavailable.'],['Edit','Economics numeric inputs F:AG and BH (runway months) are blue. Derived formulas black. All commercial scenario inputs require replacement with approved quotes/pilot results.'],['Samples',f'{len(products)} query-ASIN observations, {len({(r["country"],r["asin"]) for r in products})} distinct marketplace-ASIN pairs, 33 query pages. Not a probability sample.'],['Prices','Title-screened but mixed sizes/sets; US/UK retained Colombia delivery destination. Currency corrected through UI. No normalized domestic price distribution claimed.'],['Ratings','Displayed total ratings, not written review count; K/M rounded; pooled variants/countries possible. No review-growth trend from one snapshot.'],['Review corpus','122 visible review cards: 40 Canadian, 33 UK, 25 US, 24 other by reviewer location. US reviews obtained from imported reviews on CA/UK pages. Top/helpful sample, not complaint prevalence.'],['Formula basis','Per shipped order; discounts and refunds reduce revenue; landed cost charged once with zero returned-inventory recovery; referral refund and admin approximated. FBA charged on every shipment.'],['UK accounting','Retail price assumed VAT-inclusive at20%; referral charged on VAT-inclusive order amount. Fee VAT assumed recoverable. Customs base is factory+packaging proxy, NOT a legal valuation.'],['Break-even','BE ACoS=pre-ad contribution / initial gross discounted order revenue. BE CPC=pre-ad contribution*CVR. Blended CM assumes stated paid-order share; attribution halo ignored.'],['Capital','Inventory+reorder deposit+tax float=working capital; setup/media/overhead=planned expenses; reserve unspent buffer. No sales receipts netted. Do not add launch media again to operating expense totals.'],['Charts','01 market scope; 02 sample prices; 03 rating barriers/card concentration; 04 illustrative ad economics; 05 illustrative cash; 06 judgement scorecard.'],['Use','Choose feasibility work, not production purchase orders. No outreach, ads, purchases or launch commitments made.']]
sheet('START HERE',['Topic','Read me'],readme).set_column(1,1,110)
s=sheet('Market',['Country','Broad bedding2024 USDm','GVR CAGR2025-33 %','Offline2024 %','Home textiles2025 USDm','Bed linen share2025 %','Home textiles2026 USDm','Mordor CAGR2026-31 %','Sources','Derived bed linen2025 USDm','Derived broad online2024 USDm'],[r+[None,None] for r in market])
for i,r in enumerate(market,1):s.write_formula(i,9,f'=E{i+1}*F{i+1}/100',formula,r[4]*r[5]/100);s.write_formula(i,10,f'=B{i+1}*(1-D{i+1}/100)',formula,r[1]*(1-r[3]/100))
sheet('Product segments',['Segment','Query bucket','Demand/use cases (judgement)','Materials','Proposed specs to test','Competition','Differentiation hypothesis','Manufacturing','Recommendation'],content['segments'])
sheet('Materials',['Material','Definition','Consumer proposition','Proposed checks','Risk','Evidence'],content['materials'])
keys=list(products[0]);sheet('Competitor observations',keys,[[r[k] for k in keys] for r in products]).set_column(7,7,65)
keys=list(stats[0]);sheet('Price review barriers',keys,[[r[k] for k in keys] for r in stats])
detail=[]
for f in B.glob('PDP*.json'):
 d=json.loads(f.read_text());t=d['text'];seller=re.search(r'\nSold by\n([^\n]+)',t);ships=re.search(r'\n(?:Ships from|Dispatches from)\n([^\n]+)',t);video=re.search(r'(\d+) VIDEOS',t)
 detail.append([d['country'],d['segment'],d['asin'],' '.join(d['byline']),d['aplus_elements'],d['image_thumbnails'],(video[1]+' video references' if video else 'Video count not verified')+'; DOM presence is not quality score',len(d['reviews']),d['url'],f.stem,'Page text/specifications in evidence archive. Brand != seller != manufacturer. No inferred seller revenue.',seller[1] if seller else 'Unverified',ships[1] if ships else 'Unverified'])
sheet('Listing detail',['Country','Segment','ASIN','Byline','Aplus DOM nodes','Image thumbs','Video/quality limitation','Visible review cards','URL','Source','Notes','Observed seller','Observed shipper'],detail)
keys=list(reviews[0]);sheet('Review evidence',keys,[[r[k] for k in keys] for r in reviews]).set_column(keys.index('text'),keys.index('text'),85)
keys=list(rs[0]);sheet('Review themes',keys,[[r[k] for k in keys] for r in rs])
kw=[]
for st in stats:
 d=load(st['source']+'.json');kw.append([st['country'],d['query'],st['segment'],st['cards'],st['sponsored_cards'],'GAP','GAP','GAP','GAP','GAP','GAP','GAP','GAP',st['source'],'Observed sponsored cards only; absence is not zero ad competition. No search volume, search-share or CPC inferred. UK quilt/comforter must be localized.'])
sheet('Keywords and ads',['Market','Query','Bucket','Observed cards','Sponsored-labelled cards','Search volume','Organic rank domestic','CPC','CTR','Order CVR','ACoS','ROAS','TACoS','Source','Limit'],kw)
sheet('Channels',['Market','Channel','Demand proposition','Acquisition','Economics/operations','Suitability','Evidence'],content['channels'])
sheet('Risks',['Risk','Severity judgement','Evidence/issue','Mitigation','Verification metric','Sources'],content['risks'])
oh=['ID','Country','Opportunity','Disposition']+content['score_dimensions']+['Sources','Logic','Confidence','Weighted score']
s=sheet('Opportunity scorecard',oh,[[*o[:4],*o[4],o[5],o[6],o[7],None] for o in content['opportunities']])
for i,o in enumerate(content['opportunities'],1):s.write_formula(i,16,'=('+'+'.join(f'{xlsxwriter.utility.xl_col_to_name(j+4)}{i+1}*{wt}' for j,wt in enumerate(content['score_weights']))+')/5',formula,o[-1])
sheet('Score methodology',['Dimension','Weight %','Scale'],[[d,wt,'1=unattractive/high burden; 3=mixed or unknown; 5=attractive/low burden. Analyst judgement, not measured category score.'] for d,wt in zip(content['score_dimensions'],content['score_weights'])]+[['Confidence','Low to medium-low','Unknown CAC/quotes scored conservatively; do not interpret 1-5 point total differences as robust. A +/-1 change in a 15%-weight dimension changes total by3 points.']])
# One row per scenario. Retain fully editable formulas and cached results.
inputkeys=['id','country','currency','tier','concept','price','discount','vat','returns','factory_placeholder','packaging','freight','insurance','duty_rate','brokerage','inbound','referral','fulfilment','storage','return_handling','refund_admin','other_variable','cpc','cvr','paid_order_share','fixed_monthly','moq','launch_setup','launch_media','reorder_deposit_fraction','tax_float','reserve_rate','return_recovery']
derived=['gross_discounted','net_order','retained_revenue','customs_value_proxy','duty','landed','referral_cost','pre_ad','cpa','ad_order_cm','blended_cm','cm_pct','be_acos','be_cpc','acos','roas','tacos','be_units','be_sales','inventory_cash','reorder_cash','operating_runway','base_cash','reserve','launch_cash']
allkeys=inputkeys+derived+['evidence','runway_months'];s=sheet('Economics',allkeys,[[m.get(k) for k in allkeys] for m in models]);col={k:xlsxwriter.utility.xl_col_to_name(j) for j,k in enumerate(allkeys)}
inputpct=w.add_format({'font_name':'Arial','font_size':10,'font_color':'#0000FF','num_format':'0.0%'})
for i,m in enumerate(models,1):
 n=i+1;ref=lambda k:col[k]+str(n)
 for j,k in enumerate(inputkeys):
  if isinstance(m[k],(int,float)):s.write_number(i,j,m[k],inputpct if k in ['discount','vat','returns','duty_rate','referral','cvr','paid_order_share','reorder_deposit_fraction','reserve_rate'] else inp)
 s.write_number(i,allkeys.index('runway_months'),m['runway_months'],inp)
 f={
 'gross_discounted':f'{ref("price")}*(1-{ref("discount")})','net_order':f'{ref("gross_discounted")}/(1+{ref("vat")})','retained_revenue':f'{ref("net_order")}*(1-{ref("returns")})','customs_value_proxy':f'{ref("factory_placeholder")}+{ref("packaging")}','duty':f'{ref("customs_value_proxy")}*{ref("duty_rate")}','landed':'+'.join(ref(k) for k in ['customs_value_proxy','freight','insurance','duty','brokerage','inbound']),
 'referral_cost':f'{ref("gross_discounted")}*{ref("referral")}*(1-{ref("returns")})+{ref("returns")}*{ref("refund_admin")}',
 'pre_ad':f'{ref("retained_revenue")}-{ref("landed")}-{ref("referral_cost")}-{ref("fulfilment")}-{ref("storage")}-{ref("returns")}*{ref("return_handling")}-{ref("other_variable")}+{ref("returns")}*{ref("return_recovery")}',
 'cpa':f'IF({ref("cvr")}>0,{ref("cpc")}/{ref("cvr")},1E+9)','ad_order_cm':f'{ref("pre_ad")}-{ref("cpa")}','blended_cm':f'{ref("pre_ad")}-{ref("cpa")}*{ref("paid_order_share")}', 'cm_pct':f'{ref("blended_cm")}/{ref("retained_revenue")}','be_acos':f'{ref("pre_ad")}/{ref("gross_discounted")}','be_cpc':f'{ref("pre_ad")}*{ref("cvr")}', 'acos':f'{ref("cpa")}/{ref("gross_discounted")}','roas':f'IF({ref("acos")}>0,1/{ref("acos")},0)','tacos':f'{ref("acos")}*{ref("paid_order_share")}',
 'be_units':f'IF({ref("blended_cm")}>0,ROUNDUP({ref("fixed_monthly")}/{ref("blended_cm")},0),"No break-even at these inputs")','be_sales':f'IF(ISNUMBER({ref("be_units")}),{ref("be_units")}*{ref("gross_discounted")},"N/A")',
 'inventory_cash':f'{ref("moq")}*{ref("landed")}','reorder_cash':f'{ref("inventory_cash")}*{ref("reorder_deposit_fraction")}','operating_runway':f'{ref("fixed_monthly")}*{ref("runway_months")}','base_cash':'+'.join(ref(k) for k in ['inventory_cash','reorder_cash','launch_setup','launch_media','operating_runway','tax_float']),'reserve':f'{ref("base_cash")}*{ref("reserve_rate")}','launch_cash':f'{ref("base_cash")}+{ref("reserve")}' }
 for k,ff in f.items():s.write_formula(i,allkeys.index(k),'='+ff,pct if k in ['cm_pct','be_acos','acos','tacos'] else formula,m[k])
 s.write_comment(i,inputkeys.index('factory_placeholder'),'Budget-test assumption only. Not a factory quotation or estimate. Replace after specification-based RFQ.');s.write_comment(i,inputkeys.index('duty_rate'),m['evidence'])
sens=[]
for m in models:
 for var,mult in [('price',.9),('price',1.1),('cpc',1.25),('cvr',.75),('freight',1.5),('returns',1.5),('factory_placeholder',1.1)]:
  mm=dict(m);mm[var]*=mult;gross=mm['price']*(1-mm['discount']);ret=gross/(1+mm['vat'])*(1-mm['returns']);land=mm['factory_placeholder']+mm['packaging']+mm['freight']+mm['insurance']+(mm['factory_placeholder']+mm['packaging'])*mm['duty_rate']+mm['brokerage']+mm['inbound'];refcost=gross*mm['referral']*(1-mm['returns'])+mm['returns']*mm['refund_admin'];cm=ret-land-refcost-mm['fulfilment']-mm['storage']-mm['returns']*mm['return_handling']-mm['other_variable']-mm['cpc']/mm['cvr']*mm['paid_order_share'];sens.append([m['id'],m['currency'],var,mult,m['blended_cm'],cm,cm-m['blended_cm'],'One-factor recalculation, all other inputs fixed. UK fee rate held constant; crossing GBP20 requires category/fee recheck.'])
ss=sheet('Sensitivity',['Scenario','Currency','Variable','Multiplier','Base CM','Stress CM','Delta','Method'],sens)
for i,row in enumerate(sens,1):
 n=next(j+2 for j,m in enumerate(models) if m['id']==row[0]);var=row[2]
 def rr(k):
  v="Economics!"+col[k]+str(n)
  return '('+v+'*$D'+str(i+1)+')' if k==var else v
 gr=f'({rr("price")}*(1-{rr("discount")}))';rt=f'({gr}/(1+{rr("vat")}))*(1-{rr("returns")})';lc=f'({rr("factory_placeholder")}+{rr("packaging")})*(1+{rr("duty_rate")})+'+'+'.join(rr(k) for k in ['freight','insurance','brokerage','inbound'])
 fc=f'{gr}*{rr("referral")}*(1-{rr("returns")})+{rr("returns")}*{rr("refund_admin")}'
 cm=f'({rt})-({lc})-({fc})-{rr("fulfilment")}-{rr("storage")}-{rr("returns")}*{rr("return_handling")}-{rr("other_variable")}-{rr("cpc")}/{rr("cvr")}*{rr("paid_order_share")}+{rr("returns")}*{rr("return_recovery")}'
 ss.write_number(i,3,row[3],inp);ss.write_formula(i,4,'=Economics!'+col['blended_cm']+str(n),formula,row[4]);ss.write_formula(i,5,'='+cm,formula,row[5]);ss.write_formula(i,6,f'=F{i+1}-E{i+1}',formula,row[6])
logistics=[
['Pakistan export','PSW Single Declaration export; commercial invoice, packing list, HS classification, origin evidence; agreed Incoterm and cargo insurance','R12','Exporter/broker confirms current documents and bank/export requirements; no supplier selected'],
['US import','Importer of record, correct HTS, valuation, bond/entry and applicable additional duties; cotton traceability/UFLPA review','R27; R28','Broker quote required; US20% model input is NOT statutory rate'],
['US labels/safety','FTC fibre percentages, origin and responsible business; rayon made from bamboo; assess mattress pad 16CFR1632 / mattress1633 scope, state filled-bedding rules and applicable chemicals','R01; R02; R11','Do not apply apparel care-label rule blindly to all sheets; care instructions still commercially essential'],
['Canada import','Business/importer registration, CARM, classification/valuation, duties/taxes; cotton bed linen6302.21/31 MFN17% published in2026 schedule','R07; R26','17% is conditional illustration, not blanket Pakistan rate; no general duty-free assumption'],
['Canada labels/safety','Textile fibre disclosure English/French for national sales; dealer identification; assess provincial French requirements and product-specific safety','R19','National bilingual design baseline; legal review for final label and product type'],
['UK import','EORI/customs and VAT setup; Pakistan Enhanced Preferences under DCTS, origin declaration and product-specific origin rules','R10; R22-R25','Potential preference conditional; 2026 origin changes effective Jan1. Check actual HS6302 vs9404 and legal rule, including NI differences'],
['UK labels/tax','Fibre composition and component disclosure; VAT standard20%; product safety/UK REACH and filled-item scope; packaging obligations applicability','R04; R09','GB/NI regimes not treated as identical; verify importer and final product duties'],
['Fulfilment','Pakistan to destination3PL then FBA, direct FBA with compliant prep, or local FBM; domestic return address and disposition','Analyst route assessment','Compare end-to-end quotes, not just ocean rate; include destination charges, appointment, drayage and returns'],
['Lead times','Planning placeholders: production30-60d; ocean/end-to-end30-60d; customs/receiving7-21d; air faster but quote-dependent','ASSUMPTION, not carrier schedule','Seasonal buffers and route-specific transit quote required; sales history absent so no optimized reorder point'],
['QC','Preproduction specification, approved golden sample, fibre/weight/construction checks, repeated wash dimensions, pilling/abrasion, colourfastness, seams/closures, protector leak test','Proposed test plan; review evidence','Use accredited lab, documented methods and agreed pass limits; certificate verifies tested scope, not every marketing claim'],
['Replenishment/FX','Reorder point = expected daily orders x replenishment days + safety stock; MOQ/size assortment; settlement reserves and currency mismatch','CALC/ASSUMPTION','No observed sales forecast; model +/-10% supplier/FX cost, CAD/GBP revenue effects separately']]
sheet('Logistics compliance',['Area','Requirement/plan','Source','Verification needed'],logistics)
gaps=[['Domestic country panel','Not collected','US/UK postcode selection did not persist; no domestic ranking conclusions','Repeat fixed domestic postcodes, mobile/desktop, exact sizes and sponsored labels'],['Search demand/seasonality','Not measured','No paid keyword exports or Amazon market data','Country-specific 24-36 month query/category history; distinguish indexed trends from volume'],['Competitor sales/revenue','Unavailable','Badges, rank and ratings are not reliable revenue estimates','Licensed sales estimate with error model or verified company/category disclosures'],['CPC/CTR/CVR/ACoS/TACoS','Unavailable as market facts','No credible country x bedding segment dataset recovered','Quotation-free demand research plus capped live pilot after commercial approval'],['Review trends/negative prevalence','Not measured','122 visible cards, one snapshot, nonrandom and imported reviews','Recent stratified local-language reviews by rating and variant; dedupe and double-code'],['Supplier/landed costs','Unquoted','All factory/logistics/FBA scenario values are assumptions','Two or more comparable RFQs, lab quote, packed size/weight and broker/forwarder quote'],['True competitor concentration','Unavailable','Brand-resolved search-card concentration only','Category sales shares from reliable source; no HHI from rank or ratings'],['Channel economics','Unquoted','DTC/B2B/retail CAC and terms unknown','Buyer interviews, term sheets, parcel/3PL and payment quotations']]
sheet('Gaps and next research',['Gap','Status','Why it matters','Next evidence'],gaps)
srcrows=[]
for id,d in sources.items():
 valid=d.get('status')==200 and d.get('finalUrl',d.get('url'))==d.get('url') and not d.get('error');srcrows.append([id,d.get('url'),d.get('finalUrl'),d.get('status','Error'),'2026-10-26','Fetched page; publisher facts/claims require scope checks' if valid else 'FAILED/REDIRECT: do not use as supporting evidence',('Publisher estimates' if id.startswith('M') else 'Official' if id.startswith('R') else 'Commercial page'),d.get('fetchedAt',''),d.get('title','')[:180]])
for f in B.glob('*.json'):
 if f.stem.startswith(('LIVE_','PDP_','D0','F0','G0','LEADER_')):
  d=load(f.name);srcrows.append([f.stem,d.get('url',''),d.get('final_url',d.get('url','')),'Browser','2026-10-26','Capture; see content for access errors or location limits','Observed seller claims / official fees depending domain','',d.get('query',d.get('segment',''))])
srcrows.append(['DUNELM26','https://corporate.dunelm.com/media/a1nhsx1c/dunelm-annual-report-2026.pdf','','200','2026-10-26','Annual report FY26; share denominator combined homewares and furniture, NOT bedding','Company disclosure','','Revenue GBP1825m; share7.9%; digital42%'])
sheet('Sources',['ID','URL','Final URL','Status','Research date','Method/limits','Evidence class','Fetch timestamp','Title/note'],srcrows)
s=w.add_worksheet('Charts');s.set_column(0,14,12)
for i,name in enumerate(charts):s.insert_image(i*29,0,str(O/(name+'.png')),{'x_scale':.7,'y_scale':.7})
w.close();(B/'chart_manifest.json').write_text(json.dumps(charts));(B/'sensitivity.json').write_text(json.dumps(sens));(B/'logistics.json').write_text(json.dumps(logistics));print('BUILT',O,'products',len(products),'charts',len(charts))
