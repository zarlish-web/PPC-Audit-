import json,re,statistics,collections
from pathlib import Path
B=Path(__file__).parent
brands=['California Design Den','Niagara Sleep Solution','CGK Unlimited','CGK','Utopia Bedding','Amazon Basics','LANE LINEN','THREAD SPREAD','Bedsure','Mellanni','SONORO KATE','SafeRest','PlushDeluxe','LIFETOWN','JELLYMONI','MooMee','BESTOUCH','NEXHOME PRO','OAITE','FANSTIVE','Wake In Cloud','Sasttie','BEDLORE','EASELAND','Silentnight','Sapphire Collection','GC GAVENO CAVAILIA','GMTEXTILES','Love\'s cabin','Littens','Yard','Dreams & Drapes','HOMESCAPES','RUIKASI','Utopia','Casa Platino','TEXAS LINEN CO.','Deep Dream','Eddie Bauer','Joyreap','BEDSUM','PHF','Linenwalas','DOZ by SIJO','SIJO','DAPU','Simple&Opulence','Mayfair Linen','DECOLURE','Pure Bamboo','Bambaw','Pizuna','Fluffy Living','Linen Home','Elegant Comfort','Hearth & Harbor','Hotel Sheets Direct','LINENSPA','Lucid','ViscoSoft','Bambury','DTEX HOMES','JSD','NTBAY','BEDSURE','PRIME LINENS']
byasin={}
for f in B.glob('PDP*.json'):
 d=json.loads(f.read_text());bs=' '.join(d['byline']);bs=re.sub(r'^Visit the | Store$|^Brand: ','',bs);byasin[(d['country'],d['asin'])]=bs
def brand(t,c,a):
 if byasin.get((c,a)):return byasin[c,a]
 for b in brands:
  if b.lower() in t.lower():return b
 return 'Unresolved (title insufficient)'
def num(s):return float(s.replace(',','').replace('£','').replace('$','').strip())
def material(t):
 t=t.lower()
 if 'cotton like' in t or 'cotton-like' in t:return 'Synthetic/cotton-like claim'
 if 'microfib' in t or 'polyester' in t:return 'Synthetic or blend; verify composition'
 if 'lyocell' in t or 'tencel' in t:return 'Lyocell or blend claim'
 if 'bamboo' in t or 'rayon' in t or 'viscose' in t:return 'Regenerated cellulose or blend claim'
 if 'linen feel' in t or 'linen like' in t or 'linen-like' in t or 'linen look' in t:return 'Linen-look; not proven flax'
 if 'linen' in t and ('100%' in t or 'flax' in t):return 'Linen claim; verify flax'
 if 'cotton' in t:return 'Cotton or blend claim'
 return 'Not resolved from title'
rows=[];stats=[]
for f in sorted(B.glob('LIVE_*.json')):
 d=json.loads(f.read_text());c=d['country'];seg=d['segment'];seen=set();pr=[];rv=[]
 for rank,card in enumerate(d['cards'],1):
  a=card['asin'];t=card.get('title') or card['text'].split('\n')[0];raw=card['text'];p=card.get('price');price=None
  if p and re.match(r'^[£$][\d,.]+$',p):price=num(p)
  rat=re.search(r'(\d(?:\.\d)?) out of 5 stars',raw);rev=re.search(r'out of 5 stars\s*\(([\d,.]+)(K|M)?\)',raw)
  reviews=round(float(rev[1].replace(',',''))*({'K':1000,'M':1000000}.get(rev[2],1))) if rev else None
  promo=' | '.join(x.strip() for x in raw.splitlines() if re.search(r'coupon|Save |You pay|deal|Was:|List:|RRP:',x,re.I))
  size=next((x for x in ['California King','Cali King','Super King','Queen','King','Full/Double','Full','Double','Twin XL','Twin','Single','Standard'] if x.lower() in t.lower()),'Unspecified')
  sponsored=card.get('sponsored',False)
  # Query-result inclusions are not proof of composition or exact category.
  matched=True;tl=t.lower()
  if seg=='sheets':matched='cotton' in tl and not any(x in tl for x in ['microfib','cotton like','cotton-like','polyester'])
  if seg=='duvet':matched='cotton' in tl and 'cover' in tl
  if seg=='linen':matched=('linen' in tl or 'flax' in tl) and not any(x in tl for x in ['linen like','linen-like','linen feel','linen look','cotton','microfib','rayon','viscose','bamboo','polyester'])
  if c=='UK' and seg in ['comforter','quilt']:matched=False
  identity=(a,)
  if identity in seen:continue
  seen.add(identity)
  r={'country':c,'currency':{'US':'USD','CA':'CAD','UK':'GBP'}[c],'segment':seg,'query':d['query'],'position':rank,'asin':a,'brand':brand(raw,c,a),'title':t,'size':size,'material_claim':material(t),'display_price':price,'rating':float(rat[1]) if rat else None,'ratings_approx':reviews,'sponsored_visible':sponsored,'promotion_text':promo,'query_match_screen':matched,'bought_badge':(re.search(r'[\d,.]+[KM]?\+ bought in past month',raw).group(0) if re.search(r'[\d,.]+[KM]?\+ bought in past month',raw) else ''),'source':f.stem,'url':'https://www.amazon.'+{'US':'com','CA':'ca','UK':'co.uk'}[c]+'/dp/'+a,'research_date':'2026-10-26','limitation':'Overseas destination retained; not domestic rank or market share. Mixed variants. Rating counts may be pooled/global; K/M rounded. Price before conditional coupons; no exact delivery quote.' if c!='CA' else 'No fixed postal code; mixed variants; rating counts may be pooled/global and K/M rounded. No sales inference from badges.'}
  rows.append(r)
  if matched and price is not None:pr.append(price)
  if matched and reviews is not None:rv.append(reviews)
 local=[r for r in rows if r['source']==f.stem];counts=collections.Counter(r['brand'] for r in local if not r['brand'].startswith('Unresolved'));nknown=sum(counts.values())
 stats.append({'country':c,'segment':seg,'cards':len(local),'matched_prices':len(pr),'min':min(pr) if pr else None,'p25':statistics.quantiles(pr,n=4)[0] if len(pr)>3 else None,'median':statistics.median(pr) if pr else None,'p75':statistics.quantiles(pr,n=4)[2] if len(pr)>3 else None,'max':max(pr) if pr else None,'ratings_n':len(rv),'median_ratings':statistics.median(rv) if rv else None,'sponsored_cards':sum(r['sponsored_visible'] for r in local),'brand_resolved':nknown,'top3_known_card_share':sum(n for b,n in counts.most_common(3))/nknown if nknown else None,'top3':' / '.join(b for b,n in counts.most_common(3)),'source':f.stem})
(B/'products.json').write_text(json.dumps(rows,indent=2));(B/'sample_stats.json').write_text(json.dumps(stats,indent=2))
# Review mentions, not sentiment or incidence. Retain verbatim evidence and geography.
themes={'comfort_softness':r'soft|comfort|doux|douce|moelleux|comfy','thermal_breathability':r'cool|warm|hot|breath|heat|fresc|chaud','fit_sizing':r'fit|pocket|size|sizing|taille|deep|corner','durability_pilling':r'pill|tear|tore|rip|durab|hole|sturd','shrinkage':r'shrink|shrank|shrunk|rétr','colour_fading':r'colo[u]?r|fad|dye|bleed|stain|couleur','care_wrinkles':r'wash|dry|laundr|wrinkl|iron|crease|lav','value':r'price|value|worth|cheap|cost|prix','authenticity_material':r'polyester|cotton|bamboo|viscose|rayon|egyptian|organic|fibre|fiber','waterproof_noise':r'waterproof|leak|spill|nois|crinkl','packaging':r'packag|arriv|deliver|box'}
raw=json.loads((B/'reviews_raw.json').read_text());reviews=[];seen=set()
themes={
 'comfort_softness':r'\bsoft\w*|\bcomfort\w*|\bdoux\b|\bdouce\w*|\bmoelleux\b|\bcomfy\b',
 'thermal_breathability':r'\bcool\w*|\bwarm\w*|\bhot\b|\bbreath\w*|\bheat\w*|\bfresc\w*|\bchaud\w*',
 'fit_sizing':r'\bfit\w*|\bpocket\w*|\bsize\w*|\bsizing\b|\btaille\w*|\bdeep\b|\bcorner\w*',
 'durability_pilling':r'\bpill(?:ing|s)?\b|\btears?\b|\btore\b|\brip(?:ped|ping|s)?\b|\bdurab\w*|\bholes?\b|\bsturd\w*',
 'shrinkage':r'\bshrink\w*|\bshrank\b|\bshrunk\b|\brétr\w*',
 'colour_fading':r'\bcolo[u]?r\w*|\bfad(?:e|ed|ing)\b|\bdye\w*|\bbleed\w*|\bstain\w*|\bcouleur\w*',
 'care_wrinkles':r'\bwash\w*|\bdry\w*|\blaundr\w*|\bwrinkl\w*|\biron\w*|\bcrease\w*|\blav\w*',
 'value':r'\bprice\w*|\bvalue\b|\bworth\b|\bcheap\w*|\bcost\w*|\bprix\b',
 'authenticity_material':r'\bpolyester\b|\bcotton\b|\bbamboo\b|\bviscose\b|\brayon\b|\begyptian\b|\borganic\b|\bfib[re]+\w*',
 'waterproof_noise':r'\bwaterproof\w*|\bleak\w*|\bspill\w*|\bnois\w*|\bcrinkl\w*',
 'packaging':r'\bpackag\w*|\barriv\w*|\bdeliver\w*|\bbox\w*'}
for r in raw:
 key=r['review_id'] or r['text']
 if key in seen:continue
 seen.add(key);g=r['geo_date'];geo='CA' if g.startswith('Canada ') else 'UK' if g.startswith('the United Kingdom ') else 'US' if g.startswith('the United States ') else 'Other'
 body=r['text'].split('Verified Purchase')[-1] if 'Verified Purchase' in r['text'] else r['text'].split('Vine customer review of free product')[-1]
 hits=[k for k,pat in themes.items() if re.search(pat,body,re.I)]
 reviews.append({**r,'reviewer_country':geo,'vine':'Vine customer' in r['text'],'verified':'Verified Purchase' in r['text'],'themes':'; '.join(hits),'method':'Case-insensitive keyword mentions; multi-label; no positive/negative classification; displayed helpfulness sample, not random.'})
rs=[]
for geo in ['US','CA','UK','Other']:
 subset=[r for r in reviews if r['reviewer_country']==geo]
 for theme in themes:
  n=sum(theme in r['themes'].split('; ') for r in subset);rs.append({'reviewer_country':geo,'theme':theme,'mentions':n,'sample_n':len(subset),'share':n/len(subset) if subset else None,'interpretation':'Mention frequency only, not complaint prevalence or population estimate'})
(B/'reviews_coded.json').write_text(json.dumps(reviews,indent=2));(B/'review_stats.json').write_text(json.dumps(rs,indent=2))
print('PRODUCT_ROWS',len(rows),'UNIQUE_MARKET_ASINS',len({(r['country'],r['asin']) for r in rows}),'REVIEWS',len(reviews),'GEO',dict(collections.Counter(r['reviewer_country'] for r in reviews)))
for r in stats:
 if r['segment'] in ['sheets','duvet','protector','fitted']:print(r)
print('review themes', [r for r in rs if r['theme'] in ['fit_sizing','comfort_softness','durability_pilling']])
