import json,math
from pathlib import Path
B=Path(__file__).parent
rows=[]
# All commercial inputs are scenario placeholders, never supplier quotes or industry benchmarks.
for country,currency,prices,factories,cpcs,fulfils,fr,vat,duty in [
 ('US','USD',[29.99,69.99,79.99],[7,20,25],[.75,1.2,1.8],[4,6.5,7.5],[1,2,3],0,.20),
 ('CA','CAD',[39.99,89.99,109.99],[10,28,36],[.9,1.4,2],[5,8,9],[1.5,3,4],0,.17),
 ('UK','GBP',[19.99,49.99,64.99],[4.5,14,20],[.55,.8,1.2],[2.8,4,5],[.8,1.5,2],.20,0)]:
 for i,tier in enumerate(['Low','Medium','High']):
  r={'id':country+'-'+tier,'country':country,'currency':currency,'tier':tier,'concept':['Replacement pair/bundle','Differentiated cotton set/duvet','Broader premium cotton assortment'][i],
   'price':prices[i],'discount':.05,'vat':vat,'returns': [.05,.07,.10][i], 'factory_placeholder':factories[i], 'packaging':[.4,.8,1.2][i], 'freight':fr[i], 'insurance':[.08,.15,.25][i], 'duty_rate':duty,'brokerage':[.25,.4,.5][i], 'inbound':[.4,.65,.9][i], 'referral':.08 if country=='UK' and prices[i]*(1-.05)<=20 else .15, 'fulfilment':fulfils[i], 'storage':[.1,.25,.45][i], 'return_handling':[1.5,2.5,3.5][i], 'refund_admin':.4,'other_variable':.3,'cpc':cpcs[i],'cvr':[.08,.09,.06][i],'paid_order_share':[.6,.65,.8][i],'fixed_monthly':[500,1500,4000][i],'moq':[200,800,2400][i],'launch_setup':[1500,6000,20000][i],'launch_media':[2000,8000,25000][i],'reorder_deposit_fraction':.3,'tax_float':[200,1000,3500][i] if country!='US' else 0,'reserve_rate':.15,'return_recovery':0,
   'evidence':'All inputs ASSUMPTION except UK VAT 20% (R09), CA Home/Kitchen referral 15% (F02), and UK Home Products 8% at <=GBP20 otherwise 15% conditional category (F03). US referral15% is planning assumption. CA17% is published cotton bed-linen MFN example R26, application unverified; US20% duty is stress placeholder not legal rate; UK0% conditional DCTS, not clearance quote. Factory numbers are budget test values, NOT estimated actual manufacturing cost. FBA/storage/freight/ads require quotes or trials.'}
  r['gross_discounted']=r['price']*(1-r['discount']);r['net_order']=r['gross_discounted']/(1+vat);r['retained_revenue']=r['net_order']*(1-r['returns'])
  r['customs_value_proxy']=r['factory_placeholder']+r['packaging']
  r['duty']=r['customs_value_proxy']*duty
  r['landed']=r['customs_value_proxy']+r['freight']+r['insurance']+r['duty']+r['brokerage']+r['inbound']
  r['referral_cost']=r['gross_discounted']*r['referral']*(1-r['returns'])+r['returns']*r['refund_admin']
  r['pre_ad']=r['retained_revenue']-r['landed']-r['referral_cost']-r['fulfilment']-r['storage']-r['returns']*r['return_handling']-r['other_variable']
  r['cpa']=r['cpc']/r['cvr'];r['ad_order_cm']=r['pre_ad']-r['cpa'];r['blended_cm']=r['pre_ad']-r['cpa']*r['paid_order_share'];r['cm_pct']=r['blended_cm']/r['retained_revenue']
  r['be_acos']=r['pre_ad']/r['gross_discounted'];r['be_cpc']=r['pre_ad']*r['cvr'];r['acos']=r['cpa']/r['gross_discounted'];r['roas']=1/r['acos'];r['tacos']=r['acos']*r['paid_order_share']
  r['be_units']=math.ceil(r['fixed_monthly']/r['blended_cm']) if r['blended_cm']>0 else 'No break-even at these inputs';r['be_sales']=r['be_units']*r['gross_discounted'] if isinstance(r['be_units'],int) else 'N/A'
  r['inventory_cash']=r['moq']*r['landed'];r['reorder_cash']=r['inventory_cash']*r['reorder_deposit_fraction'];r['base_cash']=r['inventory_cash']+r['launch_setup']+r['launch_media']+r['tax_float']+r['reorder_cash'];r['reserve']=r['base_cash']*r['reserve_rate'];r['launch_cash']=r['base_cash']+r['reserve']
  r['runway_months']=3;r['operating_runway']=r['fixed_monthly']*r['runway_months'];r['base_cash']+=r['operating_runway'];r['reserve']=r['base_cash']*r['reserve_rate'];r['launch_cash']=r['base_cash']+r['reserve']
  rows.append(r)
(B/'models.json').write_text(json.dumps(rows,indent=2))
for r in rows:print(r['id'],'CM',round(r['blended_cm'],2),'BEACOS',round(r['be_acos']*100,1),'Cash',round(r['launch_cash']),r['be_units'])
