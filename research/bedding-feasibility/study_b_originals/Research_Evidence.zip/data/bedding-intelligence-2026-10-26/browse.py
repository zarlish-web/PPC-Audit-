import asyncio,json,re,sys
from pathlib import Path
from urllib.parse import quote
from playwright.async_api import async_playwright
BASE=Path(__file__).parent
async def main():
 async with async_playwright() as p:
  b=await p.chromium.connect_over_cdp('http://127.0.0.1:18801')
  ctx=await b.new_context(locale='en-US')
  jobs=json.loads((BASE/sys.argv[1]).read_text())
  sem=asyncio.Semaphore(3)
  async def run(j):
   async with sem:
    page=await ctx.new_page()
    try:
     await page.goto(j['url'],wait_until='domcontentloaded',timeout=45000)
     await page.wait_for_timeout(1500)
     txt=await page.locator('body').inner_text(timeout=10000)
     links=await page.locator('a').evaluate_all('(els)=>els.map(e=>({text:e.innerText,url:e.href})).filter(e=>e.text)')
     result={**j,'final_url':page.url,'text':txt,'links':links,'method':'anonymous browser; no postal code selected','research_date':'2026-10-26'}
     if 'amazon.' in j['url']:
      result['cards']=await page.locator('[data-component-type="s-search-result"]').evaluate_all('(els)=>els.map(e=>({asin:e.getAttribute("data-asin"),text:e.innerText}))')
     (BASE/(j['id']+'.json')).write_text(json.dumps(result,indent=2))
     print(json.dumps({'id':j['id'],'url':page.url,'text':txt[:13000] if j.get('full') else txt[:1500],'cards':result.get('cards',[])[:12]}),flush=True)
    except Exception as e:print(json.dumps({'id':j['id'],'error':str(e)[:180]}),flush=True)
    finally:await page.close()
  await asyncio.gather(*[run(j) for j in jobs])
  await ctx.close()
asyncio.run(main())
