INDEPENDENT BEDDING MARKET INTELLIGENCE
US / Canada / UK | Research date 26 October 2026

Start with Final_Decision_Memo.pdf, then the executive report.
The workbook is editable and contains 20 tabs. Blue economics inputs are assumptions unless the evidence note identifies an official parameter. All formula cells were recalculated with LibreOffice and checked for errors. 297 economics/sensitivity values were independently compared with the calculation script.

Deliverables
- Executive_Market_Intelligence_Report.pdf: 23-page independent assessment.
- Bedding_Market_Intelligence.xlsx: market, products, materials, 1,627 observations, listings, reviews, keyword gaps, channels, risks, scorecard, economics, sensitivity, logistics, sources and charts.
- Evidence_and_Scenario_Charts.pdf: six figures; scenario charts explicitly labelled.
- Final_Decision_Memo.pdf: five feasibility priorities with action, reason, evidence, logic, expected learning, metrics and risk.
- Research_Evidence.zip: public source captures, analysis datasets and reproduction scripts. Does not contain credentials, cookies or browser session state.

READ BEFORE USING
This is an evidence-limited feasibility screen, not investment-ready validation.
US/UK anonymous Amazon captures retained an overseas delivery destination despite locality-selection attempts. Display currencies were verified as USD/GBP. Canada had no fixed postal code. Samples cannot establish domestic rank, market share, domestic pricing or total Amazon demand.
The 122 visible review cards comprise 40 Canadian, 33 UK, 25 US and 24 other-country reviewers. US excerpts came from imported reviews displayed on CA/UK pages. Topic counts are not complaint rates.
Published market sizes are third-party estimates with different definitions/years. Broad home-bedding includes mattresses; derived bed-linen totals are not Amazon TAM.
Factory, freight, FBA/storage, advertising and return inputs are hypothetical budget-test assumptions, not quotes or competitor profitability estimates. Actual demand, CPC/CVR, sales/revenue, domestic panels, longitudinal reviews and supplier/landed-cost verification remain open.
No spending, outreach, supplier selection, ad change or launch commitment was made.

Reproduction
The evidence archive contains analyze.py, content.py, model.py, build.py and report.py, with their JSON inputs. Scripts use Python, openpyxl/xlsxwriter, matplotlib, ReportLab and pypdf. They expect to run from the original workspace root with data/bedding-intelligence-2026-10-26 as the source folder and reports/bedding-intelligence-2026-10-26 as output. Public-page collectors are provided for method transparency; re-running them will create new time-specific observations. Do not treat current pages as identical to archived evidence.
